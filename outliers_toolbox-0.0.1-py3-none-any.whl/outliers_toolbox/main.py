class myClass:
    def __init__(self, a) -> None:
        self.a = a

    def add(self):
        print(self.a + 1)